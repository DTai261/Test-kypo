<?
    include "config.php";
    include "dbhelp.php";
    session_start();
    if(!isset($_SESSION)){
        header('Location: Login.php');
    }
    if(!isset($_SESSION['role']) and !isset($_POST)){
        header("Location: index.php");
    }

    if($_SESSION['role'] === "teacher"){
        $dir = "Assignment/" . $_SESSION['username'];
        if(!is_dir($dir)){
            header("Location: Assignment.php");
        }
    }elseif($_SESSION['role'] === "student"){
        $dir = "Assignment/" . $_SESSION['teacher_username'] . "/" . $_POST['filename'] . "/submitted";
        if(!is_dir($dir)){
            header("Location: Assignment.php");
        }
    }

    if($_SESSION['role'] === "teacher"){
        if(!in_array($_POST['filename'], scandir($dir))){
            header("Location: Assignment.php");
        }
        $file = $dir . "/" . $_POST['filename'];
        removeFiles($file);
    }elseif($_SESSION['role'] === "student"){
        if(!in_array($_SESSION['username'] . ".txt", scandir($dir)) or !in_array($_SESSION['username'] . ".pdf", scandir($dir))){
            header("Location: Assignment.php");
        }
        $file = $dir . "/" . $_SESSION['username'] . ".txt";
        removeFiles($file);
        $file = $dir . "/" . $_SESSION['username'] . ".pdf";
        removeFiles($file);
    }

    
    function removeFiles($target) {
        if(is_dir($target)){
            $files = glob( $target . '*', GLOB_MARK );
            foreach( $files as $file ){
                removeFiles( $file ); 
            }
            rmdir( $target );
        } elseif(is_file($target)) {
            unlink( $target );  
        }
    }

    header("Location: Assignment.php?msg=deleteSuccess");
?>