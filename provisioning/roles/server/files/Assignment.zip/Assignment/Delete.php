<?
    include "config.php";
    include "dbhelp.php";
    session_start();
    // var_dump($_POST);
    if(!isset($_SESSION)){
        header('Location: Login.php');
    }
    if(!isset($_SESSION['role']) and $_SESSION['role'] !== "teacher"){
        header("Location: index.php");
    }
    $id = isset($_POST['id']) ? (int)$_POST['id'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';


    if (isset($id) and !get_role_by_ID($db, $id)){
        delete_student($db, $id, $username);
        header("location: ListStudents.php?msg=success");
    }else{
        header("location: ListStudents.php?msg=fail");
    }

    

?>