<?
    require_once('dbhelp.php');
    require_once 'config.php';
    session_start();
    if(!isset($_SESSION['role']) and !isset($_SESSION['username'])){
        header("Location: Login.php");
    }
	// var_dump($_SESSION);
    $students = get_list($db, $_SESSION['id']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>List of Student</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/List.css">


</head>
<body style="background-image: url('assets/index.jpg'); background-size: cover;">
    <div class="container">
		<div class="table-responsive">
			<div class="table-wrapper">
				<div class="table-title">
					<div class="row">
						<div class="col-xs-6">
							<!-- <h2>Manage <b>Student</b></h2> -->
                            <h2 class="nav-item">
								<a class="nav-link link display-7" style="color:azure" href="index.php">
									<span class="mbr-iconfont fa-home fa"></span>
								</a>
                            </h2>
						</div>
						<?if($_SESSION['role'] === "teacher"): ?>
						<div class="col-xs-6">
							<a href="Addstudent.php?ref=ListStudents.php" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New Student</span></a>
							<!-- <a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>						 -->
						</div>
						<?endif?>
					</div>
				</div>
				<table class="table table-striped table-hover">
					<thead>
						<tr>
                            <th>ID</th>
							<th>Username</th>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<?if($_SESSION['role'] === "teacher"): ?>
								<th>Actions</th>
							<?endif?>
						</tr>
					</thead>
					<tbody>
                        <? $count = 1; foreach ($students as $item){ ?>
                            <tr onclick="window.location='Profile.php?id=<?=$item['id']?>&ref=ListStudents.php';">
                            <!-- <tr> -->
                                <td><?=htmlspecialchars($item['id'])?></td>
								<?if($item['role'] === "teacher"):?>
									<td><?=htmlspecialchars($item['username'])?> (teacher)</td>
								<?elseif($item['role'] === "student"):?>
                                	<td><?=htmlspecialchars($item['username'])?></td>
								<?endif?>
                                <td><?=htmlspecialchars($item['fullname'])?></td>
                                <td><?=htmlspecialchars($item['email'])?></td>
                                <td><?=htmlspecialchars($item['phone'])?></td>
                                <td>
                                    <!-- <a href="Profile.php?id=" class="edit"><i class="material-icons" data-toggle="tooltip" title="View Profile">&#xE254;</i></a> -->
									<?if($_SESSION['role'] === "teacher" and $item['role'] !== "teacher"): ?>
										<form action="Delete.php" method="POST">
                                    	<!-- <a href="Delete.php?id=" onclick="confirm('Are you sure want to delete?')" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="a" title="Delete">&#xE872;</i></a> -->
											<input type="hidden" name="id" value="<?=$item['id']?>">
											<input type="hidden" name="username" value="<?=$item['username']?>">
											<input class="btn btn-success" onclick="return confirm('Are you sure want to delete?');" type="submit" value="Delete"/>
										</form>
									<?endif?>
                                </td>
                            </tr>
							 
						<?}?>
					</tbody>
				</table>     
			</div>
		</div>
    </div>
</body>
</html>