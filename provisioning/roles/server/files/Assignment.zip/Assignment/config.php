<?
    $host = "localhost";
    $user = "root";
    $password = "your_root_password";
    $dbname = "student_management";

// $db = mysqli_connect($host, $user, $password, $dbname) or die("Cannot connect to the database");

$db = new mysqli($host, $user, $password, $dbname);

// Check the connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

?>