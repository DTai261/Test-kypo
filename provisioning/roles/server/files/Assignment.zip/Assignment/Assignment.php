<?
    require_once 'dbhelp.php';
    require_once 'config.php';
    session_start();
    if(!isset($_SESSION['role']) and !isset($_SESSION['username'])){
        header("Location: Login.php");
    }
    $not_submitted = [];
    // note: POST file to remove but it not exist (hidden in post)

    //make directory for teacher to push all assigment
    if($_SESSION['role'] === "teacher"){
        $teacher_username = $_SESSION["username"];
        $dir = "Assignment/" . $teacher_username;

        if(!is_dir($dir)){
            mkdir($dir);
        }    
    }elseif($_SESSION['role'] === "student"){
        $teacher_username = get_info($db, $_SESSION['id'])['teacher_username'];
        $dir = "Assignment/" . $teacher_username;
    }
    $file_sc = scandir($dir);

    if($_SERVER['REQUEST_METHOD'] === "POST"){
        $filename = $_POST['filename'];
        if($_SESSION['role'] === "teacher"){
            $teacher = $_SESSION['username'];
            $dir = "Assignment/" . $teacher . "/" . $filename;
        }elseif($_SESSION['role'] = "student"){
            $dir = "Assignment/" . $_SESSION['teacher_username'] . "/" . $filename . "/submitted" ;
        }

        if(isset($_FILES["fileupload"])){
            $file = $_FILES["fileupload"];
    
            //file properties
            $file_name = $file['name'];
            $file_tmp = $file['tmp_name'];
            $file_size = $file['size'];
            $file_error = $file['error'];
    
            //get file extension
            $file_ext = explode('.', $file_name);
            $file_ext = strtolower(end($file_ext));
    
            $allowed = array('pdf');    
    
            if(in_array($file_ext, $allowed)){
                if($file_error === 0){
                    if($file_size <= 10000000){
                        if($_SESSION['role'] === "teacher"){
                            if(!is_dir($dir)){
                                mkdir($dir);
                            }
                            //create folder for student to submit
                            $folder_submit = $dir . "/" . "submitted";
                            if(!is_dir($folder_submit))
                            {
                                mkdir($folder_submit);
                            }
                            $new_name =  $filename  . "." . $file_ext;
                        }elseif($_SESSION['role'] === "student"){
                            $new_name = $_SESSION['username'] . "." . $file_ext;
                        }

                        $file_destination = $dir . "/" . $new_name;
    
                        
                        
                        //check file already exist
                        if (file_exists($file_destination)){
                            echo '<p style="color: red; font-size:10px;">File name already exist</p>';
                        }
                        elseif(move_uploaded_file($file_tmp, $file_destination)){
                            // unset($_FILES);
                            // unset($_POST);
                            echo '<p style="color: green; font-size:10px;">Upload file success</p>';
                        }

                    }else{
                        echo '<p style="color: red; font-size:10px;">file size must be < 10MB</p>';
                    }
                }else{
                    echo '<p style="color: red; font-size:10px;">Fail to upload file</p>';
                }
            }else{
                echo '<p style="color: red; font-size:10px;">Invalid file type</p>';
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Assignment</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/List.css">
<link rel="stylesheet" href="css/assignment.css">
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">

</head>
<body style="background-image: url('assets/Assignment.jpg'); background-size: cover;">

<div class="container bootstrap snippets bootdey">
    <hr>
    <ol class="breadcrumb">
    	<li><a href="index.php">Home</a></li>
	</ol>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="well profile">
                <img class="user img-circle pull-left clearfix" height="54" src="https://bootdey.com/img/Content/user_1.jpg" alt="">
                <h3 class="name pull-left clearfix"><?=$_SESSION['fullname']?></h3>
                <div class="clearfix"></div><br>
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#tab" data-toggle="tab">
                        	Overview
                        </a>
                    </li>
                    <li class="">
                        <a href="#tab2" data-toggle="tab">
                        	Upload file
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab">
                    <!-- here -->
                    <div class="container" style="width: 98%;">
                        <div class="table-responsive">
                            <div class="table-wrapper">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Assignment name</th>
                                            <th>Submitted</th>
                                            <?if($_SESSION['role'] === "teacher"):?>
                                                <th>View Detail</th>
                                            <?endif?>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?    
                                        
                                        if($_SESSION['role'] === "teacher"){
                                            $dir = "Assignment/" . $teacher_username;
                                        }else{
                                            $dir = "Assignment/" . $teacher_username;
                                        }
                                        $allowed = array('pdf');
                                        $choosen_file = "";
                                        for($i = 2; $i < sizeof($file_sc); $i++){
                                            $count = $i - 1;           
                                            if(sizeof($file_sc) > 2){
                                                ?>
                                                <tr>
                                                    <td><?=$count?></td>
                                                    <!-- these line should be above -->
                                                    <?if($_SESSION['role'] === "student"){
                                                        $download_assignment = "Assignment/" . $_SESSION['teacher_username'] . "/" . $file_sc[$i] . "/" . $file_sc[$i] . ".pdf";
                                                    }elseif($_SESSION['role'] === "teacher"){
                                                        $download_assignment = "Assignment/" . $_SESSION['username'] . "/" . $file_sc[$i] . "/" . $file_sc[$i] . ".pdf";
                                                    }
                                                    ?>
                                                    
                                                    <td><a href="Download.php?download=<?=$download_assignment?>&ref=Assignment.php"><?=$file_sc[$i]?></a></td>
                                                    <?if($_SESSION['role'] === "teacher"):
                                                        $file_dir = $dir . "/" . $file_sc[$i] . "/submitted";
                                                        $submitted = sizeof(scandir($file_dir)) - 2;
                                                    ?>
                                                        <td><?=$submitted?>/<?=count_student($db, $_SESSION['username'])?></td>
                                                    <?else:
                                                        $check_submitted = false;
                                                        $file_dir = $dir . "/" . $file_sc[$i] . "/submitted";
                                                        if(in_array($_SESSION['username'] . ".pdf",scandir($file_dir))){
                                                            $check_submitted = true;
                                                            $download_submit = "Assignment/" . $_SESSION['teacher_username'] . "/" . $file_sc[$i] . "/submitted/" . $_SESSION['username'] . ".pdf";
                                                        }else{
                                                            array_push($not_submitted, $file_sc[$i]);
                                                        }
                                                        if($check_submitted):?>
                                                            <td><a href="Download.php?download=<?=$download_submit?>"style="color:green; font-size:150%">&#10004;</a></td>
                                                        <?else:?>
                                                            <td></td>
                                                        <?endif;
                                                    endif?>
                                                    <!-- only teacher can view detail of all of the submit -->
                                                    <?if($_SESSION['role'] === "teacher" and $submitted !== 0):?>
                                                        <td><a data-toggle="collapse" href="#detail<?=$count?>" style="color: green"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                                    <?elseif($_SESSION['role'] === "teacher" and $submitted === 0):?>
                                                        <td><a><i class="fa fa-eye" aria-hidden="true"></i></a></td>
                                                    <?endif?>
                                                    <td>
                                                        <?if($_SESSION['role'] === "teacher"): ?>
                                                            <form action="DeleteAssignment.php" method="POST">
                                                                <input type="hidden" name="filename" value="<?=$file_sc[$i]?>">
                                                                <input class="btn btn-danger" onclick="return confirm('Are you sure want to delete this assignment?');" type="submit" value="Delete"/>
                                                            </form>
                                                        <?else:?>
                                                            <?if($check_submitted):?>
                                                                <form action="DeleteAssignment.php" method="POST">
                                                                    <input type="hidden" name="filename" value="<?=$file_sc[$i]?>">
                                                                    <input class="btn btn-danger"  onclick="return confirm('Are you sure want to delete this submit?');" type="submit" value="Delete"/>
                                                                </form>
                                                            <?else:?>
                                                                <?$choosen_file = $i;?>
                                                                <button class="btn btn-success" href="#tab2" data-toggle="tab">
                                                                    Submit
                                                                </button>
                                                            <?endif?>
                                                        <?endif?>
                                                    </td>
                                                </tr>
                                                <!-- hidden data -->
                                                <?if($_SESSION['role'] === "teacher"):?>
                                                <tr>
                                                    <td colspan="12">
                                                        <div class="accordian-body collapse" id="detail<?=$count?>">
                                                        <table class="table table-striped table-hover">
                                                            <thead>
                                                            <tr class="info">
                                                                <th>ID</th>
                                                                <th></th>
                                                                <th>username</th>
                                                                <th></th>
                                                                <th>Full name</th>
                                                                <th>Download file</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?
                                                                $list_student_summited = scandir($file_dir);
                                                                if(sizeof($list_student_summited) > 2){
                                                                for($j = 2; $j < sizeof($list_student_summited); $j++){
                                                                    // get the username from file name
                                                                    $student_username = explode(".", $list_student_summited[$j])[0];
                                                                    $student_id = get_id($db, $student_username)['id'];
                                                                    $student_name = get_id($db, $student_username)['fullname'];
                                                                    $student_submit = "Assignment/" . $_SESSION['username'] . "/" .$file_sc[$i] . "/submitted/" . $list_student_summited[$j];
                                                                
                                                            ?>
                                                                    <tr onclick="window.location='Profile.php?id=<?=$student_id?>&ref=Assignment.php';">
                                                                        <td><?=$student_id?></td>
                                                                        <th></th>
                                                                        <th><?=$student_username?></th>
                                                                        <th></th>
                                                                        <td><?=$student_name?></td>
                                                                        <td><a href="Download.php?download=<?=$student_submit?>" style="color: green"><i class="fa fa-download" aria-hidden="true"></i></a></td>
                                                                        <?//$student_submit?>
                                                                    </tr>
                                                            
                                                            <!-- end of for loop and if -->
                                                            <?}}?>
                                                            </tbody>
                                                        </table>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?endif?>
                                                <!-- hidden data -->
                                                <?
                                            }
                                        }
                                    ?>
                                    
                                    </tbody>
                                </table>     
                            </div>
                        </div>
                    </div>
                    <!-- end -->
                    </div>
                    <div class="tab-pane" id="tab2">
                        <div class="row">
                            <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="basic">
                                        <form class="form-horizontal" action="Assignment.php#tab2" method="POST" enctype="multipart/form-data">
                                            <br>
                                            <?if($_SESSION['role'] === "teacher"):?>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Assignment name</label>
                                                    <div class="col-lg-10">
                                                        <input type="text" class="form-control" name="filename" >
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label  class="col-lg-2 control-label">Choose pdf file here</label>
                                                    <div class="col-lg-10">
                                                        <input type="file" class="form-control" id="filestyle-0" name="fileupload"> 
                                                    </div>    
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-lg-10" >
                                                            <button class="btn float-right" type="submit" name="teacher_upload" value="submit">Submit</button>
                                                </div>
                                            <?elseif($_SESSION['role'] === "student"):?>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Choose Assignment to submit</label>
                                                    <div class="col-lg-10">
                                                    <select class="form-control" name="filename">
                                                        <?foreach($not_submitted as $file){
                                                            // var_dump($file); echo "<br>"; var_dump($choosen_file); echo "<br>";
                                                            if($file !== $file_sc['choosen_file']){?>
                                                                <option><?=$file?></option>
                                                            <?}else{?>
                                                                <option selected="selected"><?=$file?></option>;
                                                            <?}
                                                        }?>
                                                    </select>
                                                    </div>
                                                </div>
                                                    <div class="form-group">
                                                        <label  class="col-lg-2 control-label">Choose or pdf file here</label>
                                                        <div class="col-lg-10">
                                                            <input type="file" class="form-control" id="filestyle-0" name="fileupload"> 
                                                        </div>    
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-lg-10" >
                                                                <button class="btn float-right" type="submit" name="student_upload" value="submit">Submit</button>
                                                    </div>
                                                    </div>
                                            <?endif?>
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <?//var_dump($not_submitted);?>
</body>                    
</html>