<?

session_start();
if(!isset($_SESSION)){
    header('Location: Login.php');
}

if(!isset($_SESSION['role']) and !isset($_SESSION['id'])){
    header("Location: index.php");
}



if($_SERVER['REQUEST_METHOD'] === "POST"){
    if(check_empty($_POST)){
        $check = true;
        // find solution for this later
        $_POST['username'] = strtolower(mysqli_real_escape_string($db, $_POST['username']));
        $_POST['fullname'] = ucfirst(mysqli_real_escape_string($db, $_POST['fullname']));
        $_POST['password'] = mysqli_real_escape_string($db, $_POST['password']);
        $_POST['confirm_password'] = mysqli_real_escape_string($db, $_POST['confirm_password']);
        $_POST['email'] = mysqli_real_escape_string($db, $_POST['email']);
        $_POST['phone'] = mysqli_real_escape_string($db, $_POST['phone']);
        $_POST['dob'] = mysqli_real_escape_string($db, $_POST['dob']);
        $_POST['gender'] = mysqli_real_escape_string($db, $_POST['gender']);
        $_POST['address'] = mysqli_real_escape_string($db, $_POST['address']);
        $_POST['ID_card'] = mysqli_real_escape_string($db, $_POST['ID_card']);
        $_POST['class'] = mysqli_real_escape_string($db, $_POST['class']);
        $_POST['rollnumber'] = mysqli_real_escape_string($db, $_POST['rollnumber']);
        $_POST['role'] = "student";

        if(is_exist_username($db, $_POST['username'])){
            $check = false;
            $msg_username = "Username already exist";
        }

        if(!check_password($_POST['password'])){
            $check = false;
            $msg_password = "password must contain lower, upper case, number and special character";
        }

        if($_POST['password'] !== $_POST['confirm_password']){
            $check = false;
            $msg_confirm_pass = "confirm passwoord not match";
        }

        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $check = false;
            $msg_email = "in valid email address";
        }

        if (!preg_match('#[\d]{10}#', $_POST['phone'])) {
            $check = false;
            $msg_email = "in valid phone number";
        } 

        if($check){
            insert_student($db, $_POST);
            $msg_success = "add new student success !";
            unset($_POST);
        }

    }else{
        $msg_error = "You must fill in all the information first";
    }
}

?>